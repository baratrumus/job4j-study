package ru.job4j.generic;

public class RoleStore extends AbstractStore {

    RoleStore(int size) {
        super(size);
    }
}
