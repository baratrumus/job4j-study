package ru.job4j.singleton;

import ru.job4j.tracker.*;

/**
 * вариант singleton на перечислениях
 */
enum  SingletonEnum {
    INSTANCE
}
