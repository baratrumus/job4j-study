package ru.job4j.pseudo;


/**
 * Интерфейс формы
 * @author ivannikov
 * @version $Id$
 * @since 0.1
 */

public interface Shape {
    String draw();
}
