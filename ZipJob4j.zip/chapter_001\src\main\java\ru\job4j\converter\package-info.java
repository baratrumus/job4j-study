/**
 * Package for calculator task.
 *
 * @author Ilya Ivannikov (baratrumus@yandex.ru)
 * @version $Id$
 * @since 0.1
 */
package ru.job4j.converter;