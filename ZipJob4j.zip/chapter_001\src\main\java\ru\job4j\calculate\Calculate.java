package ru.job4j.calculate;

/**
 * Class Класс для вывода строки Hello World
 * @author ivannikov
 * @since 02.04.2019
 * @version 1
 */

public class Calculate {
	/**
	 * Method echo.
	 * @param name Your name.
	 * @return Echo plus  your name.
	 */
	public String echo(String name) {
		return "Echo, echo, echo : " + name;
	}

	/**
	 * Main
	 * @param args - args.
	 */
	public static void main(String[] args) {
		System.out.println("Hello World");
	}









}



