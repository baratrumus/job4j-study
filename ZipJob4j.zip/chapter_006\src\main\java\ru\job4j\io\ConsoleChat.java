package ru.job4j.io;


import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Создать программу 'Консольный чат'. Пользователь вводит слово-фразу, программа берет случайную фразу
 * из текстового файла и выводит в ответ. Программа замолкает если пользователь вводит слово «стоп»,
 * при этом он может продолжать отправлять сообщения в чат. Если пользователь вводит слово «продолжить»,
 * программа снова начинает отвечать. При вводе слова «закончить» программа прекращает работу.
 * Запись диалога включая, слова-команды стоп/продолжить/закончить записать в текстовый лог.
 */
public class ConsoleChat {
/*
    private final Input input;
    private final Tracker tracker;
    private boolean exit;
    private final Consumer<String> output;*/
    /**
     * Конструктор инициализирующий поля.
     * @param input ввод данных.
     * @param tracker хранилище заявок.
     * @param output   Вывод программы сделан через Consumer<String>
     */
 /*   public StartUI(Input input, Tracker tracker, boolean exit, Consumer<String> output) {
        this.input = input;
        this.tracker = tracker;
        this.exit = exit;
        this.output = output;
    }

    /**
     * Запуск программы.
     * @param args
     */
 /*   public static void main(String[] args) {

        new StartUI(new ValidateInput(new ConsoleInput()), new Tracker(), false, System.out::println).init();
    }



    public void init() {

        MenuTracker menu = new MenuTracker(this.input, this.tracker, this.output);
        menu.fillActions(this);
        List<Integer> menuRange = new ArrayList<>();
        for (int i = 0; i < menu.getActionsLength(); i++) {
            menuRange.add(i);
        }
        do {
            menu.show();
            menu.select(Integer.valueOf(input.ask("Введите пункт меню : ", menuRange)));
        } while (!this.exit);
    }

    public void stop() {
        this.exit = true;
    }
*/

}
