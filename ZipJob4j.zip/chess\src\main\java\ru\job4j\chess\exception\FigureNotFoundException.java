package ru.job4j.chess.exception;

public class FigureNotFoundException  extends Exception {
    public FigureNotFoundException(String msg) {
        super(msg);
    }
}