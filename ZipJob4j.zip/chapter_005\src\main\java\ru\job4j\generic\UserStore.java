package ru.job4j.generic;

public class UserStore extends AbstractStore {

    UserStore(int size) {
        super(size);
    }
}
