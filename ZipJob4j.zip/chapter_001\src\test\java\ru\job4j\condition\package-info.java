/**
* Package for test calculate.
*
* @author Ilya Ivannikov (baratrumus@yandex.ru)
* @version $Id$
* @since 0.1
*/
package ru.job4j.condition;