package Collections.PriorityLinkedList;

public class Node {
    public int iData;
    public Node next;

    public Node(int x) {
        iData = x;
    }
    public void displayNode() {
        System.out.println(iData + " ");
    }
}

