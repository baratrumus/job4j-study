package DesignPatterns.Strategy;

public interface FlyBehavior {
    public void fly();
}
