package DesignPatterns.Strategy.TestStrategy;

public interface RunStyle {
    void run(int length);
}
