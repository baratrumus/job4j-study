package DesignPatterns.Strategy.TestStrategy;

public interface JumpBehavior {
    void jump();
}
