package DesignPatterns.Strategy;

public interface QuackBehavior {
    public void quack();
}
